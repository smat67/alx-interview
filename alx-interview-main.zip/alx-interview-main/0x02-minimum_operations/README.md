# Minimum Operations
