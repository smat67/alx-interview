# N - Queens
